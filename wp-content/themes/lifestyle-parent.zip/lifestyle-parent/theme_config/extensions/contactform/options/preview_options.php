<?php
$options = array(
    array(
        'type' => 'css',
        'dir'  => get_template_directory().'/theme_config/extensions/contactform/static/css',
        'filename' => 'contact_form'
    ),
	    array(
        'type' => 'js',
        'dir'  => get_template_directory().'/js',
        'filename' => 'ui.selectmenu'
    )
);