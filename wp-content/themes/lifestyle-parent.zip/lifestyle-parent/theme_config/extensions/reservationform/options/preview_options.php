<?php
$options = array(
    array(
        'type' => 'css',
        'dir'  => get_template_directory().'/theme_config/extensions/reservationform/static/css',
        'filename' => 'reservation_form'
    ),
	    array(
        'type' => 'js',
        'dir'  => get_template_directory().'/js',
        'filename' => 'ui.selectmenu'
    )
);