<?php

$cfg['categories'] = array(
    'Text & Images' => 1,
    'Buttons & Lists' => 2,
    'Charts' => 3,
    'Columns' => 4,
    'PrettyPhoto' => 5,
    'Media' => 6,
    'Tables & Boxes' => 7,
    'Tabs & Toggles' => 8,
    'Typography' => 9,
    'Maps' => 10,
    'Widgets' => 11
);
