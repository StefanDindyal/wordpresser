<div id="slider_html_masks">
    <div id="slide_image_framebox">
        <li class="image_frame">
            <img class="slider_image_preview" preview="" src=""/>
            <div class="active_edit"></div>
            <div class="remove_frame" title="Delete Slide."></div>
        </li>
    </div>
</div>
<ul id="slider_frames"></ul>
