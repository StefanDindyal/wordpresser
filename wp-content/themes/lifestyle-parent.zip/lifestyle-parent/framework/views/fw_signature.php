<!--
Using theme: <?php echo $theme_name; ?> by ThemeFuse.com 
Elapsed time: <?php echo $elapsed_time; ?> seconds 
Memory usage: <?php echo number_format($memory_usage, 0, '.', ','); ?> bytes 
-->