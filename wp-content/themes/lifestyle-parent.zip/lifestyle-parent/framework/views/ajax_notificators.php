<style>.tfuse-save-popup{display:none}</style>

<div id="tfuse-ajax-loading-img" class="tfuse-save-popup">
    <div class="tfuse-save-loading">
        <img src="<?php echo get_template_directory_uri(); ?>/framework/static/images/loading.gif" alt="Loading..." />
    </div>
</div>

<div id="tfuse-popup-save" class="tfuse-save-popup"><div class="tfuse-save-save"><?php _e('Changes Saved', 'tfuse'); ?></div></div>
<div id="tfuse-popup-reset" class="tfuse-save-popup"><div class="tfuse-save-reset"><?php _e('Options Reseted', 'tfuse'); ?></div></div>
<div id="tfuse-popup-fail" class="tfuse-save-popup"><div class="tfuse-save-reset"><?php _e('Changes Not Saved', 'tfuse'); ?></div></div>
