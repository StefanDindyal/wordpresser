<?php

define('FILE_CACHE_DIRECTORY', '../../cache/');
