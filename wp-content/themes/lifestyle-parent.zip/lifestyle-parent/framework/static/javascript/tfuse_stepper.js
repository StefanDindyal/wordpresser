jQuery(document).ready(function(){
    jQuery('.tfuse-stepper').stepper();
});

