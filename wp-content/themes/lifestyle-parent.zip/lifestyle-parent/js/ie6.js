 jQuery(document).ready(function(){
		$.reject({
			close: false,
			imagePath: '<?php echo $template_directory ?>/images/'
		});
});

