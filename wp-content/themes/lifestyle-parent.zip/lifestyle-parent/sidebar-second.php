<?php
tf_do_placeholder('yellow');