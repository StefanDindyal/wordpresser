<?php get_header(); ?>
<div id="main-content" class="main-content">
	<div class="rig">
		<div id="primary" class="content-area">
			<div id="content" class="site-content" role="main">
				Content goes here.
			</div><!-- #content -->
		</div><!-- #primary -->
	</div>
</div><!-- #main-content -->

<?php
get_footer();
