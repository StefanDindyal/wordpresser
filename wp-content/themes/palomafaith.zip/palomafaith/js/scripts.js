jQuery( document ).ready(function( $ ) {	
	
	// Extend
	$.extend(verge);	

	if($(window).width() <= 640){
		// $('.featured').removeClass('featured').addClass('lines');
		$('#epilogue .passage .nav-options .audio').append($('.nav-options .audio .player'));
		$('.burger').on('click', function(e){
			e.preventDefault();
			if($(this).hasClass('active')){
				$(this).removeClass('active');
				$('#book #logo .nav-menu').slideUp(300);
			} else {
				$(this).addClass('active');
				$('#book #logo .nav-menu').slideDown(300);
			}
		});
		// $("#book #logo .newsletter-mob").on('click', function(e){
		// 	e.preventDefault();

		// });
		$("#book #logo .newsletter-mob").fancybox({
			padding: 0,
			margin: 0,			
			scrolling : 'yes',
			fitToView : false,
			helpers : {
		        overlay : {
		            css : {
		                'background' : 'rgba(0, 0, 0, 0.70)'
		            }
		        }
		    }
		});

		if($('.tour.sec').length){
			$('.tour-block .event:gt(3)').hide();
		}
	}

	if($(window).width() <= 1024){
		if($('.passage').length){		
			checkPos();
			$('#epilogue .spot .in').bxSlider({'auto':'true','pause':'5000','adaptiveHeight':'true','mode':'fade'});
			$('#social .social-target .social-block').bxSlider({'mode':'vertical'});
			$('#photos .picture .target').bxSlider({'mode':'fade'});
			var videoSlide = $('#videos .panel .target').bxSlider({'mode':'fade', 'video':'true',onSlideAfter: function(){$('#videos .hold').empty().hide();$('.vid-controls').removeClass('move-please');}});
			$('#videos .next').on('click', function(e){
				e.preventDefault();
				videoSlide.goToNextSlide();
			});
			$('#videos .prev').on('click', function(e){
				e.preventDefault();
				videoSlide.goToPrevSlide();
			});
			$('#videos .play-btn').on('click', function(e){
				e.preventDefault();
				var parent = $(this).parents('.entry-header');
				var videoSrc = parent.find('.entry-thumbnail').attr('data-vid');
				var hold = parent.find('.hold');
				var iframe = '<iframe id="yt-vid-embed" frameborder="0" allowfullscreen="1" src="'+videoSrc+'"></iframe>';
				$('.vid-controls').addClass('move-please');
				hold.append(iframe);
				hold.show();
			});
		}
		$('#lang_sel a.lang_sel_sel').on('click', function(e){
			e.preventDefault();
			if($(this).hasClass('down')){
				$(this).removeClass('down');
				$(this).parents('li').find('ul').slideUp(250);
			} else {
				$(this).addClass('down');
				$(this).parents('li').find('ul').slideDown(250);
			}		
		});
		$('.videos.sec .play-btn').on('click', function(e){
			e.preventDefault();
			var parent = $(this).parents('.entry-header');
			var videoSrc = parent.find('.entry-thumbnail').attr('data-vid');
			var hold = parent.find('.hold');
			var iframe = '<iframe id="yt-vid-embed" frameborder="0" allowfullscreen="1" src="'+videoSrc+'"></iframe>';		
			$('.videos.sec .hold').empty().hide();
			hold.append(iframe);
			hold.show();
		});
		$('.nav-menu a, a.return').on('click', function(e){
			if($(this).hasClass('return')){
				var me = $(this).attr('data-id');
			} else {
				var me = $(this).parents('li').attr('class').split(' ')[0];
			}
			var clicks = $('#'+me);
			if(clicks.length){
				e.preventDefault();				
				if($(window).width() == 568) {
					var destination = $(clicks).offset().top * 0.887;	
				} else if($(window).width() == 480) {
					var destination = $(clicks).offset().top * 0.75;	
				} else if($(window).width() == 360) {
					var destination = $(clicks).offset().top * 0.538;	
				} else if($(window).width() == 320) {
					var destination = $(clicks).offset().top * 0.5;	
				} else {
					var destination = $(clicks).offset().top;
				}
				$("html:not(:animated),body:not(:animated)").animate({scrollTop: destination}, 1000, function(){
					checkPos();
				});
			}
		});
		$(".signup > a").on('click', function(e){
			e.preventDefault();
			if($(this).parents('.signup').hasClass('active')){
				$(this).parents('.signup').removeClass('active');			
			} else {
				$(this).parents('.signup').addClass('active');
			}		
		});
		$(".signup .slip a.close").on('click', function(e){
			e.preventDefault();
			$(this).parents('.signup').removeClass('active');		
		});
		$(".audio > a").on('click', function(e){
			e.preventDefault();
			if($(this).parents('.audio').hasClass('active')){
				$(this).parents('.audio').removeClass('active');
				$('.jp-player').jPlayer('stop');
			} else {
				$(this).parents('.audio').addClass('active');
			}		
		});
		$(".audio .player a.close").on('click', function(e){
			e.preventDefault();
			$(this).parents('.audio').removeClass('active');
			$('.jp-player').jPlayer('stop');
		});
		$(".signup .slip .nl").fancybox({
			padding: 0,
			margin: 0,
			fitToView	: false,			
			helpers : {
		        overlay : {
		            css : {
		                'background' : 'rgba(0, 0, 0, 0.70)'
		            }
		        }
		    }
		});
		$(window).scroll(function(){
			if(!$('html,body').is(':animated')){
				if($('.passage').length){
					checkPos();
				}
			}
		});	
		$('.page').addClass('active');
		$('#logo').addClass('active');		
		
	} else {		
		var scrollorama = $.scrollorama({ blocks:'.page', enablePin:false });
		if($('.passage').length){			
			checkPosMob();
			scrollorama
				.animate('.tab',{ delay: 250, duration: 500, property:'top', start:-100, end:0 })
				.animate('.tab',{ delay: 250, duration: 500, property:'opacity', start:0, end:1 });
			scrollorama
				.animate('.drops',{ delay: 250, duration: 1000, property:'top', start:-300, end:100 })
				.animate('.drops',{ delay: 250, duration: 1000, property:'opacity', start:0, end:1 });		
			scrollorama
				.animate('.lights.full',{ delay: 250, duration: 1000, property:'top', start:-300, end:-70 });		
			scrollorama
				.animate('.lights.one',{ delay: 250, duration: 1000, property:'top', start:100, end:0 })
				.animate('.lights.two',{ delay: 250, duration: 1000, property:'top', start:100, end:0 })	
				.animate('.lights.three',{ delay: 250, duration: 1000, property:'top', start:100, end:0 })
				.animate('.lights.four',{ delay: 250, duration: 1000, property:'top', start:100, end:0 });
			$('#epilogue .spot .in').bxSlider({'auto':'true','pause':'5000','adaptiveHeight':'true','mode':'fade'});
			$('#social .social-target .social-block').bxSlider({'mode':'vertical'});
			$('#photos .picture .target').bxSlider({'mode':'fade'});
			var videoSlide = $('#videos .panel .target').bxSlider({'mode':'fade', 'video':'true',onSlideAfter: function(){$('#videos .hold').empty().hide();$('.vid-controls').removeClass('move-please');}});
			$('#videos .next').on('click', function(e){
				e.preventDefault();
				videoSlide.goToNextSlide();
			});
			$('#videos .prev').on('click', function(e){
				e.preventDefault();
				videoSlide.goToPrevSlide();
			});
			$('#videos .play-btn').on('click', function(e){
				e.preventDefault();
				var parent = $(this).parents('.entry-header');
				var videoSrc = parent.find('.entry-thumbnail').attr('data-vid');
				var hold = parent.find('.hold');
				var iframe = '<iframe id="yt-vid-embed" frameborder="0" allowfullscreen="1" src="'+videoSrc+'"></iframe>';
				$('.vid-controls').addClass('move-please');
				hold.append(iframe);
				hold.show();
			});
		}
		$('.nav-menu a, a.return').on('click', function(e){		
			if($(this).hasClass('return')){
				var me = $(this).attr('data-id');			
			} else {
				var me = $(this).parents('li').attr('class').split(' ')[0];	
			}		
			var clicks = $('#'+me);
			if(clicks.length){
				e.preventDefault();			
				var destination = $(clicks).offset().top;
				$("html:not(:animated),body:not(:animated)").animate({scrollTop: destination}, 1000, function(){
					checkPosMob();	
				});
			}
		});
		$(window).scroll(function(){
			if(!$('html,body').is(':animated')){
				if($('.passage').length){
					checkPosMob();
				}
			}
		});					
		$('#lang_sel a.lang_sel_sel').on('click', function(e){
			e.preventDefault();
			if($(this).hasClass('down')){
				$(this).removeClass('down');
				$(this).parents('li').find('ul').slideUp(250);
			} else {
				$(this).addClass('down');
				$(this).parents('li').find('ul').slideDown(250);
			}		
		});
		$('.videos.sec .play-btn').on('click', function(e){
			e.preventDefault();
			var parent = $(this).parents('.entry-header');
			var videoSrc = parent.find('.entry-thumbnail').attr('data-vid');
			var hold = parent.find('.hold');
			var iframe = '<iframe id="yt-vid-embed" frameborder="0" allowfullscreen="1" src="'+videoSrc+'"></iframe>';		
			$('.videos.sec .hold').empty().hide();
			hold.append(iframe);
			hold.show();
		});		
		$(".signup > a").on('click', function(e){
			e.preventDefault();
			if($(this).parents('.signup').hasClass('active')){
				$(this).parents('.signup').removeClass('active');			
			} else {
				$(this).parents('.signup').addClass('active');
			}		
		});
		$(".signup .slip a.close").on('click', function(e){
			e.preventDefault();
			$(this).parents('.signup').removeClass('active');		
		});
		$(".audio > a").on('click', function(e){
			e.preventDefault();
			if($(this).parents('.audio').hasClass('active')){
				$(this).parents('.audio').removeClass('active');
				$('.jp-player').jPlayer('stop');
			} else {
				$(this).parents('.audio').addClass('active');
			}		
		});
		$(".audio .player a.close").on('click', function(e){
			e.preventDefault();
			$(this).parents('.audio').removeClass('active');
			$('.jp-player').jPlayer('stop');
		});
		$(".signup .slip .nl").fancybox({
			padding: 0,
			margin: 0,
			fitToView	: false,		
			helpers : {
		        overlay : {
		            css : {
		                'background' : 'rgba(0, 0, 0, 0.70)'
		            }
		        }
		    }
		});		
	
	}	

	$(".single-gallery-item a").fancybox({
		padding: 0,
		margin: 10,
		fitToView	: true,		
		helpers : {
	        overlay : {
	            css : {
	                'background' : 'rgba(0, 0, 0, 0.70)'
	            }
	        }
	    }
	});	

	function checkPos(){		
			var scroll = $.scrollY();
			var socialY = $('#social').offset().top;
			var newsY = $('#news').offset().top;
			var tourY = $('#tour').offset().top;
			var photosY = $('#photos').offset().top;
			var videosY = $('#videos').offset().top;
			var epilogue = 0;
			var social = socialY - ((newsY - socialY) / 2);
			var news = newsY - ((tourY - newsY) / 2);
			var tour = tourY - ((photosY - tourY) /2);
			var photos = photosY - ((videosY - photosY) /2);		
			var videos = videosY - 525;			
			$('.nav-menu a').removeClass('current-nav-item');			
			if(scroll >= epilogue && scroll < social){							
			}
			else if(scroll >= social && scroll < news){			
				$('.nav-menu .social a').addClass('current-nav-item');
			}
			else if(scroll >= news && scroll < tour ){			
				$('.nav-menu .news a').addClass('current-nav-item');
			}
			else if(scroll >= tour && scroll < photos){			
				$('.nav-menu .tour a').addClass('current-nav-item');
			}
			else if(scroll >= photos && scroll < videos){							
				$('.nav-menu .photos a').addClass('current-nav-item');
			}
			else if(scroll >= videos){				
				$('.nav-menu .videos a').addClass('current-nav-item');			
			}
			if(scroll <= videos){
				$('#videos .hold').empty().hide();
				$('.vid-controls').removeClass('move-please');
			}
		}

	function checkPosMob(){		
			var scroll = $.scrollY();
			var socialY = $('#social').offset().top;
			var newsY = $('#news').offset().top;
			var tourY = $('#tour').offset().top;
			var photosY = $('#photos').offset().top;
			var videosY = $('#videos').offset().top;
			var epilogue = 0;
			var social = socialY - ((newsY - socialY) / 2);
			var news = newsY - ((tourY - newsY) / 2) + 400;
			var tour = tourY - ((photosY - tourY) /2);
			var photos = photosY - ((videosY - photosY) /2);		
			var videos = videosY - 145;
			$('.page').removeClass('active');
			$('.nav-menu a').removeClass('current-nav-item');
			if(scroll >= 45){
				$('#logo').addClass('active');
			} else {
				$('#logo').removeClass('active');
			}
			if(scroll >= epilogue && scroll < social){			
				$('#epilogue').addClass('active');			
			}
			else if(scroll >= social && scroll < news){			
				$('#social').addClass('active');
				$('.nav-menu .social a').addClass('current-nav-item');
			}
			else if(scroll >= news && scroll < tour ){			
				$('#news').addClass('active');
				$('.nav-menu .news a').addClass('current-nav-item');
			}
			else if(scroll >= tour && scroll < photos){			
				$('#tour').addClass('active');
				$('.nav-menu .tour a').addClass('current-nav-item');
			}
			else if(scroll >= photos && scroll < videos){			
				$('#photos').addClass('active');
				$('.nav-menu .photos a').addClass('current-nav-item');
			}
			else if(scroll >= videos){
				$('#videos').addClass('active');
				$('.nav-menu .videos a').addClass('current-nav-item');			
			}
			if(scroll <= videos){
				$('#videos .hold').empty().hide();
				$('.vid-controls').removeClass('move-please');
			}
		}

});
