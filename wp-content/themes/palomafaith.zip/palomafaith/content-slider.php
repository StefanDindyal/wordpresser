<?php
	global $slider_subtext, $slider_url, $slider_target, $cta_text;
	$slider_subtext = get_post_meta($post->ID, 'pf_slider_subtext', true);
	$slider_url = get_post_meta($post->ID, 'pf_slider_url', true);
	$slider_target = get_post_meta($post->ID, 'pf_slider_target', true);
	$cta_text = get_post_meta($post->ID, 'pf_cta_text', true);
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header clearfix">
		<?php if ( has_post_thumbnail() && ! post_password_required() ) : ?>
		<div class="entry-thumbnail">
			<?php the_post_thumbnail('spot-thumb'); ?>
		</div>
		<?php endif; ?>		
	</header><!-- .entry-header -->
	<h1 class="entry-title"><?php the_title(); ?></h1>
	<?php if($slider_url){
		if($cta_text){
			echo '<a href="'.$slider_url.'" title="buy now" target="_blank" class="btn">'.$cta_text.'</a>';
		} else {
			echo '<a href="'.$slider_url.'" title="buy now" target="_blank" class="btn">buy now</a>';	
		}		
	}?>
</article><!-- #post -->
