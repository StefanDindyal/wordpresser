<?php get_header(); ?>
<div id="news-page">
	<div id="news" class="section">		
		<div class="letter">				
			<h2><?php the_title(); ?></h2>
			<div class="block clearfix">
				<div class="notice">
					This page requires a template.
				</div>
			</div>
		</div>
	</div>	
</div>
<?php
get_footer();
