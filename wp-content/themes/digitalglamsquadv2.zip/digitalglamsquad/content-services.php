<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="entry-title"><?php the_title(); ?></div>
	<div class="service-disc">
		<?php the_content(); ?>
	</div>	
</article><!-- #post -->